/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pages;

import AppPackage.AnimationClass;
import Pages.Dialog_Box;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
//import Front_Page.loginpage;

/**
 *
 * @author Sudhanshu Kumar
 */
public class User_Portal_ITS extends javax.swing.JFrame {

    /**
     * Creates new form UserPortal
     */
     AnimationClass AC = new AnimationClass();
    
    public User_Portal_ITS() {
        initComponents();
        SlideShow();
        setIconImage();
    }
private void setIconImage() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/assets/icon.png")));
    }

    public void SlideShow(){
        new Thread()
        {
            int count;
            @Override
            public void run()
            {
                try
                {
                    while(true){
                    
                        switch(count){
                        
                            case 0: 
                                ImageIcon II = new ImageIcon(getClass().getResource("/assets/its4.jpg"));
                                background1.setIcon(II);
                                
                                Thread.sleep(5500);
                                
                                AC.jLabelXLeft(0, -1040, 30, 16, background1);
                                AC.jLabelXLeft(1040, 0, 30, 16, background2);
                                
                                count = 1;
                                break;
                                
                            case 1: 
                                ImageIcon II1 = new ImageIcon(getClass().getResource("/assets/its1.jpg"));
                                background2.setIcon(II1);
                                
                                Thread.sleep(5500);
                                
                                AC.jLabelXRight(-1040, 0, 30, 16, background1);
                                AC.jLabelXRight(0, 1040, 30, 16, background2);
                                
                                count = 2;
                                break;
                                
                            case 2: 
                                ImageIcon II3 = new ImageIcon(getClass().getResource("/assets/its2.jpg"));
                                background1.setIcon(II3);
                                
                                
                                Thread.sleep(5500);
                                
                                AC.jLabelXLeft(0, -1040, 30, 16, background1);
                                AC.jLabelXLeft(1040, 0, 30, 16, background2);
                                
                                count = 3;
                                break;
                                
                            case 3: 
                                ImageIcon II4 = new ImageIcon(getClass().getResource("/assets/its3.jpg"));
                                background2.setIcon(II4);
                                
                                Thread.sleep(5500);
                                
                                AC.jLabelXRight(-1040, 0, 30, 16, background1);
                                AC.jLabelXRight(0, 1040, 30, 16, background2);
                                
                                count = 4;
                                break;
                                
                            case 4: 
                                ImageIcon II5 = new ImageIcon(getClass().getResource("/assets/its1.jpg"));
                                background1.setIcon(II5);
                                
                                
                                Thread.sleep(5500);
                                
                                AC.jLabelXLeft(0, -1040, 30, 16, background1);
                                AC.jLabelXLeft(1040, 0, 30, 16, background2);
                                
                                count = 5;
                                break;
                                
                            case 5: 
                                ImageIcon II6 = new ImageIcon(getClass().getResource("/assets/its2.jpg"));
                                background2.setIcon(II6);
                                
                                Thread.sleep(5500);
                                
                                AC.jLabelXRight(-1040, 0, 30, 16, background1);
                                AC.jLabelXRight(0, 1040, 30, 16, background2);
                                
                                count = 0;
                                break;
                                
                            
                        }
                    }
                }
                catch(Exception e){
                    
                }
            }
        }.start();
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        layeredpanel = new javax.swing.JLayeredPane();
        home = new javax.swing.JPanel();
        kGradientPanel2 = new keeptoo.KGradientPanel();
        close4 = new javax.swing.JLabel();
        background1 = new javax.swing.JLabel();
        background2 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        search = new javax.swing.JPanel();
        kGradientPanel3 = new keeptoo.KGradientPanel();
        close1 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        source = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        destination = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tablepanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        search_result = new javax.swing.JTable();
        display = new javax.swing.JLabel();
        about = new javax.swing.JPanel();
        kGradientPanel6 = new keeptoo.KGradientPanel();
        close5 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        menu = new javax.swing.JPanel();
        kGradientPanel1 = new keeptoo.KGradientPanel();
        btn1 = new keeptoo.KButton();
        btn2 = new keeptoo.KButton();
        btn3 = new keeptoo.KButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("User Portal");
        setLocation(new java.awt.Point(300, 80));
        setResizable(false);

        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("true"), this, org.jdesktop.beansbinding.BeanProperty.create("undecorated"));
        bindingGroup.addBinding(binding);

        layeredpanel.setLayout(new java.awt.CardLayout());

        kGradientPanel2.setkEndColor(new java.awt.Color(51, 0, 204));
        kGradientPanel2.setkStartColor(new java.awt.Color(102, 204, 255));
        kGradientPanel2.setPreferredSize(new java.awt.Dimension(1040, 930));
        kGradientPanel2.setLayout(null);

        close4.setFont(new java.awt.Font("Segoe UI Emoji", 0, 24)); // NOI18N
        close4.setText("X");
        close4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        close4.setMaximumSize(new java.awt.Dimension(200, 200));
        close4.setMinimumSize(new java.awt.Dimension(200, 200));
        close4.setPreferredSize(new java.awt.Dimension(200, 200));
        close4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close4MouseClicked(evt);
            }
        });
        kGradientPanel2.add(close4);
        close4.setBounds(1000, 20, 20, 40);
        kGradientPanel2.add(background1);
        background1.setBounds(0, 170, 1040, 693);
        kGradientPanel2.add(background2);
        background2.setBounds(1040, 170, 1040, 693);

        jLabel23.setFont(new java.awt.Font("Sitka Small", 1, 28)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Welcome to Intelligent Transportation System");
        kGradientPanel2.add(jLabel23);
        jLabel23.setBounds(160, 100, 710, 36);

        javax.swing.GroupLayout homeLayout = new javax.swing.GroupLayout(home);
        home.setLayout(homeLayout);
        homeLayout.setHorizontalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        homeLayout.setVerticalGroup(
            homeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 911, Short.MAX_VALUE)
        );

        layeredpanel.add(home, "card2");

        kGradientPanel3.setkEndColor(new java.awt.Color(51, 0, 204));
        kGradientPanel3.setkStartColor(new java.awt.Color(102, 204, 255));
        kGradientPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        close1.setFont(new java.awt.Font("Segoe UI Emoji", 0, 24)); // NOI18N
        close1.setText("X");
        close1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        close1.setMaximumSize(new java.awt.Dimension(200, 200));
        close1.setMinimumSize(new java.awt.Dimension(200, 200));
        close1.setPreferredSize(new java.awt.Dimension(200, 200));
        close1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close1MouseClicked(evt);
            }
        });
        kGradientPanel3.add(close1, new org.netbeans.lib.awtextra.AbsoluteConstraints(998, 16, 27, 43));

        jLabel21.setFont(new java.awt.Font("Sitka Small", 1, 28)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Search Your Buses here !");
        kGradientPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(308, 18, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Showcard Gothic", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 153));
        jLabel4.setText("Enter Source Location");

        source.setFont(new java.awt.Font("Tahoma", 0, 28)); // NOI18N
        source.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 2, new java.awt.Color(51, 153, 255)));
        source.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sourceActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Showcard Gothic", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 153));
        jLabel5.setText("Enter Destination Location");

        destination.setFont(new java.awt.Font("Tahoma", 0, 28)); // NOI18N
        destination.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 2, 2, new java.awt.Color(51, 153, 255)));
        destination.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                destinationActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/location.png"))); // NOI18N

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/assets/search button.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(source, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(destination, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(58, 58, 58))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(destination, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel1)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(source, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel2)
                .addGap(0, 27, Short.MAX_VALUE))
        );

        kGradientPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 103, 960, 230));

        jScrollPane1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        search_result.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        search_result.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "BUS ID", "Departs", "Arrives", "FROM", "TO", "Total Time", "Distance", "Fare", "Route No."
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        search_result.setRowHeight(36);
        jScrollPane1.setViewportView(search_result);
        if (search_result.getColumnModel().getColumnCount() > 0) {
            search_result.getColumnModel().getColumn(0).setResizable(false);
            search_result.getColumnModel().getColumn(1).setResizable(false);
            search_result.getColumnModel().getColumn(2).setResizable(false);
            search_result.getColumnModel().getColumn(3).setResizable(false);
            search_result.getColumnModel().getColumn(4).setResizable(false);
            search_result.getColumnModel().getColumn(5).setResizable(false);
            search_result.getColumnModel().getColumn(6).setResizable(false);
            search_result.getColumnModel().getColumn(7).setResizable(false);
            search_result.getColumnModel().getColumn(8).setResizable(false);
        }

        javax.swing.GroupLayout tablepanelLayout = new javax.swing.GroupLayout(tablepanel);
        tablepanel.setLayout(tablepanelLayout);
        tablepanelLayout.setHorizontalGroup(
            tablepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 960, Short.MAX_VALUE)
        );
        tablepanelLayout.setVerticalGroup(
            tablepanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tablepanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        kGradientPanel3.add(tablepanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 390, 960, 400));

        display.setIcon(new javax.swing.ImageIcon("C:\\Users\\sudha\\Desktop\\Untitled-1.png")); // NOI18N
        kGradientPanel3.add(display, new org.netbeans.lib.awtextra.AbsoluteConstraints(91, 449, -1, -1));

        javax.swing.GroupLayout searchLayout = new javax.swing.GroupLayout(search);
        search.setLayout(searchLayout);
        searchLayout.setHorizontalGroup(
            searchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        searchLayout.setVerticalGroup(
            searchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        layeredpanel.add(search, "card3");

        kGradientPanel6.setkEndColor(new java.awt.Color(51, 0, 204));
        kGradientPanel6.setkStartColor(new java.awt.Color(102, 204, 255));

        close5.setFont(new java.awt.Font("Segoe UI Emoji", 0, 24)); // NOI18N
        close5.setText("X");
        close5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        close5.setMaximumSize(new java.awt.Dimension(200, 200));
        close5.setMinimumSize(new java.awt.Dimension(200, 200));
        close5.setPreferredSize(new java.awt.Dimension(200, 200));
        close5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                close5MouseClicked(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Showcard Gothic", 0, 40)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("About");

        javax.swing.GroupLayout kGradientPanel6Layout = new javax.swing.GroupLayout(kGradientPanel6);
        kGradientPanel6.setLayout(kGradientPanel6Layout);
        kGradientPanel6Layout.setHorizontalGroup(
            kGradientPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel6Layout.createSequentialGroup()
                .addContainerGap(1003, Short.MAX_VALUE)
                .addComponent(close5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, kGradientPanel6Layout.createSequentialGroup()
                .addGap(0, 349, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(343, 343, 343))
        );
        kGradientPanel6Layout.setVerticalGroup(
            kGradientPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(close5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(133, 133, 133)
                .addComponent(jLabel11)
                .addContainerGap(672, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout aboutLayout = new javax.swing.GroupLayout(about);
        about.setLayout(aboutLayout);
        aboutLayout.setHorizontalGroup(
            aboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        aboutLayout.setVerticalGroup(
            aboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        layeredpanel.add(about, "card5");

        kGradientPanel1.setkEndColor(new java.awt.Color(51, 0, 255));
        kGradientPanel1.setkStartColor(new java.awt.Color(204, 102, 255));

        btn1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 8, 0, 0, new java.awt.Color(0, 102, 204)));
        btn1.setText("Home");
        btn1.setFont(new java.awt.Font("Perpetua Titling MT", 1, 28)); // NOI18N
        btn1.setkBackGroundColor(new java.awt.Color(153, 153, 255));
        btn1.setkBorderRadius(0);
        btn1.setkEndColor(new java.awt.Color(102, 0, 255));
        btn1.setkHoverEndColor(new java.awt.Color(51, 153, 255));
        btn1.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btn1.setkHoverStartColor(new java.awt.Color(102, 0, 255));
        btn1.setkPressedColor(new java.awt.Color(51, 153, 255));
        btn1.setkSelectedColor(new java.awt.Color(51, 153, 255));
        btn1.setkStartColor(new java.awt.Color(51, 153, 255));
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });

        btn2.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 8, 0, 0, new java.awt.Color(0, 102, 204)));
        btn2.setText("search Bus Routes");
        btn2.setFont(new java.awt.Font("Perpetua Titling MT", 1, 28)); // NOI18N
        btn2.setkBorderRadius(0);
        btn2.setkEndColor(new java.awt.Color(102, 0, 255));
        btn2.setkHoverEndColor(new java.awt.Color(51, 153, 255));
        btn2.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btn2.setkHoverStartColor(new java.awt.Color(102, 0, 255));
        btn2.setkPressedColor(new java.awt.Color(51, 153, 255));
        btn2.setkSelectedColor(new java.awt.Color(51, 153, 255));
        btn2.setkStartColor(new java.awt.Color(51, 153, 255));
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });

        btn3.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 8, 0, 0, new java.awt.Color(0, 102, 204)));
        btn3.setText("About Us");
        btn3.setFont(new java.awt.Font("Perpetua Titling MT", 1, 28)); // NOI18N
        btn3.setkBorderRadius(0);
        btn3.setkEndColor(new java.awt.Color(102, 0, 255));
        btn3.setkHoverEndColor(new java.awt.Color(51, 153, 255));
        btn3.setkHoverForeGround(new java.awt.Color(255, 255, 255));
        btn3.setkHoverStartColor(new java.awt.Color(102, 0, 255));
        btn3.setkPressedColor(new java.awt.Color(51, 153, 255));
        btn3.setkSelectedColor(new java.awt.Color(51, 153, 255));
        btn3.setkStartColor(new java.awt.Color(51, 153, 255));
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout kGradientPanel1Layout = new javax.swing.GroupLayout(kGradientPanel1);
        kGradientPanel1.setLayout(kGradientPanel1Layout);
        kGradientPanel1Layout.setHorizontalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(btn1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btn3, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );
        kGradientPanel1Layout.setVerticalGroup(
            kGradientPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(kGradientPanel1Layout.createSequentialGroup()
                .addContainerGap(327, Short.MAX_VALUE)
                .addComponent(btn1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn3, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(378, 378, 378))
        );

        javax.swing.GroupLayout menuLayout = new javax.swing.GroupLayout(menu);
        menu.setLayout(menuLayout);
        menuLayout.setHorizontalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(kGradientPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        menuLayout.setVerticalGroup(
            menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(menuLayout.createSequentialGroup()
                .addComponent(kGradientPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(layeredpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1040, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(layeredpanel, javax.swing.GroupLayout.PREFERRED_SIZE, 911, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        bindingGroup.bind();

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        // TODO add your handling code here:
        layeredpanel.removeAll();
        layeredpanel.add(home);
        layeredpanel.repaint();
        layeredpanel.revalidate();
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        // TODO add your handling code here:
        layeredpanel.removeAll();
        layeredpanel.add(search);
        layeredpanel.repaint();
        layeredpanel.revalidate();
        
        
        
    }//GEN-LAST:event_btn2ActionPerformed

    private void close1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close1MouseClicked
    
       System.exit(0);
    }//GEN-LAST:event_close1MouseClicked

    private void close4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close4MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_close4MouseClicked

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        // TODO add your handling code here:
        layeredpanel.removeAll();
        layeredpanel.add(about);
        layeredpanel.repaint();
        layeredpanel.revalidate();

    }//GEN-LAST:event_btn3ActionPerformed

    private void close5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_close5MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_close5MouseClicked

    private void sourceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sourceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sourceActionPerformed

    private void destinationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_destinationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_destinationActionPerformed

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        
         
       String Dsource = source.getText();
       String Ddestination = destination.getText();
        
        if(Dsource.isEmpty() || Ddestination.isEmpty()){
        Dialog_Box ob = new Dialog_Box();
        ob.setVisible(true);
        ob.text.setText("     Please enter all details");
        
        }
        else{
        
        
        //Displaying search result in Table
         try {
            String url = "jdbc:mysql://127.0.0.1:3306/its?autoReconnect=true&useSSL=false";
            String uname = "root";
            String pass = "password@1234";
            String query = "select * from its.bus_details where source_location = '"+Dsource+"' and destination_location = '"+Ddestination+"'" ;
            Class.forName("com.mysql.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cooldude?autoReconnect=true&useSSL=false","root","password@1234");
            Statement st = con.createStatement();

            ResultSet pqs = st.executeQuery(query);
           // if(pqs.isBeforeFirst()){

            DefaultTableModel tbmodel = (DefaultTableModel)search_result.getModel();
                
            while(pqs.next()){            
            String data[] = {pqs.getString(1),pqs.getString(2),pqs.getString(3),pqs.getString(4),pqs.getString(5),pqs.getString(6),pqs.getString(7),pqs.getString(8),pqs.getString(9)};
            tbmodel.addRow(data);
            }
//            }
//            else{
//            search_result.setVisible(false);
//            }
           
            st.close();
            con.close();

        } catch (Exception E) {
            E.printStackTrace();
        }
        }
    }//GEN-LAST:event_jLabel2MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User_Portal_ITS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User_Portal_ITS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User_Portal_ITS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User_Portal_ITS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User_Portal_ITS().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel about;
    private javax.swing.JLabel background1;
    private javax.swing.JLabel background2;
    private keeptoo.KButton btn1;
    private keeptoo.KButton btn2;
    private keeptoo.KButton btn3;
    private javax.swing.JLabel close1;
    private javax.swing.JLabel close4;
    private javax.swing.JLabel close5;
    private javax.swing.JTextField destination;
    public javax.swing.JLabel display;
    private javax.swing.JPanel home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private keeptoo.KGradientPanel kGradientPanel1;
    private keeptoo.KGradientPanel kGradientPanel2;
    private keeptoo.KGradientPanel kGradientPanel3;
    private keeptoo.KGradientPanel kGradientPanel6;
    private javax.swing.JLayeredPane layeredpanel;
    private javax.swing.JPanel menu;
    private javax.swing.JPanel search;
    private javax.swing.JTable search_result;
    private javax.swing.JTextField source;
    private javax.swing.JPanel tablepanel;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

}
